#!/usr/bin/env bash
# Runs once inside the "setup" container (as root, from /usr/share/elasticsearch)
set -eu

CERTS_DIR=config/certs
CA="$CERTS_DIR/ca/ca.crt"
ES_URL=https://es01:9200

for v in ELASTIC_PASSWORD KIBANA_PASSWORD LOGSTASH_WRITER_PASSWORD; do
  if [ -z "${!v:-}" ]; then
    echo "ERROR: set $v in the .env file"
    exit 1
  fi
done

# ---------- TLS certificates ----------
if [ ! -f "$CERTS_DIR/ca.zip" ]; then
  echo "Creating CA"
  bin/elasticsearch-certutil ca --silent --pem -out "$CERTS_DIR/ca.zip"
  unzip -o "$CERTS_DIR/ca.zip" -d "$CERTS_DIR"
fi

if [ ! -f "$CERTS_DIR/certs.zip" ]; then
  echo "Creating node certificates"
  cat > "$CERTS_DIR/instances.yml" << YAML
instances:
  - name: es01
    dns:
      - es01
      - localhost
    ip:
      - 127.0.0.1
YAML
  bin/elasticsearch-certutil cert --silent --pem \
    -out "$CERTS_DIR/certs.zip" \
    --in "$CERTS_DIR/instances.yml" \
    --ca-cert "$CERTS_DIR/ca/ca.crt" \
    --ca-key "$CERTS_DIR/ca/ca.key"
  unzip -o "$CERTS_DIR/certs.zip" -d "$CERTS_DIR"
fi

echo "Setting file permissions"
chown -R root:root "$CERTS_DIR"
find "$CERTS_DIR" -type d -exec chmod 750 {} \;
find "$CERTS_DIR" -type f -exec chmod 640 {} \;
# The CA certificate is public; Logstash runs outside the root group and needs to read it
chmod 755 "$CERTS_DIR" "$CERTS_DIR/ca"
chmod 644 "$CA"

# ---------- Wait for Elasticsearch ----------
echo "Waiting for Elasticsearch..."
until curl -s --cacert "$CA" "$ES_URL" | grep -q "missing authentication credentials"; do
  sleep 5
done

AUTH="elastic:${ELASTIC_PASSWORD}"
JSON="Content-Type: application/json"

echo "Setting kibana_system password"
until curl -s -X POST --cacert "$CA" -u "$AUTH" -H "$JSON" \
  "$ES_URL/_security/user/kibana_system/_password" \
  -d "{\"password\":\"${KIBANA_PASSWORD}\"}" | grep -q "^{}"; do
  sleep 5
done

echo "Creating logstash_writer role"
until curl -s -X POST --cacert "$CA" -u "$AUTH" -H "$JSON" \
  "$ES_URL/_security/role/logstash_writer" -d '{
    "cluster": ["monitor", "manage_index_templates", "manage_ilm"],
    "indices": [{
      "names": ["logs-*", "logstash-*", "ecs-logstash-*"],
      "privileges": ["write", "create", "create_doc", "create_index",
                     "auto_configure", "manage", "manage_ilm", "view_index_metadata"]
    }]
  }' | grep -q '"role"'; do
  sleep 5
done

echo "Creating logstash_writer user"
until curl -s -X POST --cacert "$CA" -u "$AUTH" -H "$JSON" \
  "$ES_URL/_security/user/logstash_writer" \
  -d "{\"password\":\"${LOGSTASH_WRITER_PASSWORD}\",\"roles\":[\"logstash_writer\"],\"full_name\":\"Logstash Writer\"}" \
  | grep -q '"created"'; do
  sleep 5
done

echo "Setup complete!"
